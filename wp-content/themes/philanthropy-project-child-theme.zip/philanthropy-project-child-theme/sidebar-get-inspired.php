<aside class="sidebar sidebar-get-inspired">

	<?php dynamic_sidebar('sidebar_get_inspired') ?>

</aside>
