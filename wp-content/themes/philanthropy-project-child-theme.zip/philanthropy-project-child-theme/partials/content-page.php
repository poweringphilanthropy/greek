		<article id="post-<?php the_ID() ?>" <?php post_class() ?>>			
		
			<div class="entry cf">
				<?php //get_template_part( 'partials/featured-image' ) ?>
				<?php the_content() ?>
			</div>						

		</article>