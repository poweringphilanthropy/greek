jQuery(document).ready(function($){

    var doc = $(document);