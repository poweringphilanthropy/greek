<div class="cuztom-checkbox">
    <?php echo $field->outputOption($value, $field->default_value, 'on'); ?>
</div>
