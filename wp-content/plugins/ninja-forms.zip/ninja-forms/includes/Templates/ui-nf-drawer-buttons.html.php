<ul class="nf-drawer-buttons">
    <li class="nf-drawer-delete"><span class="dashicons dashicons-dismiss"></span><?php _e( 'Delete', 'ninja-forms' ); ?></li>
    <li class="nf-drawer-duplicate"><span class="dashicons dashicons-admin-page"></span><?php _e( 'Duplicate', 'ninja-forms' ); ?></li>
</ul>
